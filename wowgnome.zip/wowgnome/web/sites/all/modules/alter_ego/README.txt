Alter Ego is a helper module that allows users to attach other "Avatar" to their account.  The selected main avatar's name
and (optional) picture will replace this users name and picture in posts.

The main usage of this module is is association with another gaming module that will provide and skin a type of gaming avatar.  For example
wowguild.module creates and updates World of Warcraft avatars and allows users to add their World of Warcraft characters to their account, and 
become their main character with a picture will update as their in-game character changes their gear.

IMPORTANT NOTE: Install and enable this module *before* enabling any dependancy module.  Dependant modules do not seem to enable in order and will throw
an error if both modules are enabled at the same time.  (If anyone knows a fix for this, please open an issue!)
